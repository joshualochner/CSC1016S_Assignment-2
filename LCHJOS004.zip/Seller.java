/*
Seller class used to model shops with various attributes
*/
public class Seller {
   public String ID;
   public String name;
   public String location;
   public String product;
   public Money unit_price;
   public int number_of_units;
}